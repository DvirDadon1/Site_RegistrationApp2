package com.example.Site_RegisterationApp;
import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * @author		Dvir Dadon <dd2640@bs.amalnet.k12.il
 * @version	4.2.1
 * This class can help you to scan QR code.
 */

public class CaptureAct extends CaptureActivity{
}
